(function() {
  var timer = document.getElementById('timer');

  if (window.location.search === "?false") {
    return;
  }

  var timeLeft = parseInt(window.location.search.substr(1));

  var endDateTime = new Date();
  endDateTime.setMinutes(endDateTime.getMinutes() + (isNaN(timeLeft) ? 45 : timeLeft));

  setInterval(function() {
    var timeSpan = Math.ceil((endDateTime - new Date()) / 1000)

    var minutes, seconds;
    minutes = Math.floor(timeSpan / 60);
    seconds = timeSpan % 60;

    if (timeSpan >= 0) {
      timer.innerText = minutes + ":" + ("0" + seconds).substr(-2);
    }

  }, 100);
}).call(this)
